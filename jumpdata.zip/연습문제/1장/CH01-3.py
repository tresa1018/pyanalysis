import turtle
t = turtle.Turtle( )
t.shape("turtle")

t.up( )
t.goto(-150, 0)
t.down( )
t.circle(80)

t.up( )
t.goto(0, 0)
t.down( )
t.circle(80)

t.up( )
t.goto(150, 0)
t.down( )
t.circle(80)

t.up( )
t.goto(-80, -100)
t.down( )
t.circle(80)

t.up( )
t.goto(80, -100)
t.down( )
t.circle(80)
