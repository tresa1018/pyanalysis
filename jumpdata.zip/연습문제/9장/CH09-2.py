domains = { "kr": "대한민국", "sk": "슬로바키아", "no": "노르웨이" }

for k, v in domains.items( ):
    print (k, ": ", v)
