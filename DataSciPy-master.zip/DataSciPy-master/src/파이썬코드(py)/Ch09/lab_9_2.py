#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# LAB 9-2 트위터 메시지 처리의 단어 추출, 229쪽
#
t = "There's a reason some people are working to make it harder to vote, especially for people of color. It’s because when we show up, things change."

length = len(t.split(' '))
print('word count:', length)