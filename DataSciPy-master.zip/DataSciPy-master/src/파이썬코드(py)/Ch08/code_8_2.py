#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# 8.2 딕셔너리의 기능을 알아보자, 201쪽
#
person_dic = {'Name': '홍길동', 'Age': 27, 'Class': '초급'} 
 
print(person_dic['Name'])   # 딕셔너리의 'Name'이라는 키로 값을 조회함
print(person_dic['Age'])    # 딕셔너리의 'Age'이라는 키로 값을 조회함