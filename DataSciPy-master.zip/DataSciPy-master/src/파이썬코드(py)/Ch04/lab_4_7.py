#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# LAB 4-7 로그인 처리하기, 109쪽
#
id = "ilovepython"
s = input("아이디를 입력하시오: ")
if s == id:
    print("환영합니다.")
else:
    print("아이디를 찾을 수 없습니다.")