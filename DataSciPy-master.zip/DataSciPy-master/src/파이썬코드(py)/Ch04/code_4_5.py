#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# 4.5 배타적 조건에 따라 실행하는 if-else 문, 96쪽
#
if score >= 60:
    print("합격입니다.")
else:
    print("불합격입니다.")

hour = 10

if hour < 12:
    print('오전입니다.')
else:
    print('오후입니다.')