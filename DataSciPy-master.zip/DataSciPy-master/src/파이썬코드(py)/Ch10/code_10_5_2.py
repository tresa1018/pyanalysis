#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# 10.5 강력한 넘파이 배열의 연산을 알아보자, 255쪽
#
import numpy as np 

salary = np.array([220, 250, 230]) 
salary = salary * 2 
print(salary)