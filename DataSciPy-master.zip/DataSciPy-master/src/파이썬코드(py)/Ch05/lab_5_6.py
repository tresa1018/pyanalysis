#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# LAB 5-6 사용자로부터 암호를 받아 로그인하기, 128쪽
#
password = ""
while password != "pythonisfun":
    password = input("암호를 입력하시오: ")
print("** 로그인 성공 **")