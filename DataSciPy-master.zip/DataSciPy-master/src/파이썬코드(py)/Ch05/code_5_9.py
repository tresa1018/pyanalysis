#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# 5.9 무한 루프와 break로 빠져나가기, 137쪽
#
while True:
    light = input('신호등 색상을 입력하시오:')
    if light == 'green':
        break
print('전진!!')