#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# 5.8 일정한 횟수 반복에 while 사용하기, 129쪽
#
count = 1
s = 0
while count <= 10:
    s = s + count
    count = count + 1
print("합계는", s)