#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# LAB 1-2 터틀 그래픽으로 삼각형을 그려 보자, 37쪽
#
import turtle
t = turtle.Turtle()
t.shape("turtle")

t.forward(100)
t.left(120)
t.forward(100)
t.left(120)
t.forward(100)

turtle.done()