#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# 6.13 모듈을 이용해서 함수를 두고두고 재사용하자, 165쪽
#
import datetime

print(datetime.datetime.now())

today = datetime.datetime.today()
print(today)
print(today.year)
print(today.month)
print(today.day)