#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# 6.4 함수에 하나의 값을 넘겨주고 일을 시키자, 149쪽
#
def print_address(name):
    print("서울 특별시 종로구 1번지")
    print("파이썬 빌딩 7층")
    print(name)

print_address("홍길동")
print_address("널널한 교수")