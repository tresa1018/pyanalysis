#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# 6.14 나만의 모듈을 만들고 불러서 사용해 보자, 166쪽
#
from my_func import *

mf_print('-no module name-', 2)