def mf_print(msg, n=1):
    print(msg * n)