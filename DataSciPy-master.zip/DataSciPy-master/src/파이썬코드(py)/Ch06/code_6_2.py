#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# 6.2 def 예약어를 이용하여 함수를 작성하고 호출하기, 147쪽
#
def print_address():
    print('경상북도')
    print('울릉군 울릉읍')
    print('독도리 산 1-96번지')


print_address()  # 정의한 함수를 호출
print_address()  # 정의한 함수를 호출
print_address()  # 정의한 함수를 호출