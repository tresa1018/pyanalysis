#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# 6.3 함수를 만들고 불러서 일을 시켜보자, 148쪽
#
print('경상북도')
print('울릉군 울릉읍')
print('독도리 산 1-96번지')


def print_address():
    print('경상북도')
    print('울릉군 울릉읍')
    print('독도리 산 1-96번지')


print_address()
print_address()
print_address()