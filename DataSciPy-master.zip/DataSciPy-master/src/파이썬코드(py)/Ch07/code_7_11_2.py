#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# 7.11 리스트를 탐색해보자, 185쪽
#
bts = ["V", "J-Hope", "Suga", "Jungkook" ] 
for member in bts: 
    print(member)