#
# 따라하며 배우는 파이썬과 데이터과학(생능출판사 2020)
# 7.8 항목을 삭제하는 방법은 여러가지가 있다, 182쪽
#
bts = ["V", "J-Hope", "Suga", "Jungkook" ] 

if "Suga" in bts: 
    bts.remove("Suga")