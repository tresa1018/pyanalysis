if "Suga" in bts: 
    print(bts.index("Suga"))

################################################

bts = ["V", "J-Hope", "Suga", "Jungkook" ] 
for member in bts: 
    print(member)