# 따라하며 배우는 파이썬과 데이터과학 소스 코드 - 코랩 접속 주소

### 1장  소스 코드 : 데이터 과학과 파이썬의 세계로
https://colab.research.google.com/drive/1FWcl48s7Mr4p9G-sGv80Fj7TIeb1YaN0?usp=sharing
### 2장 소스 코드 : 값을 담아 다루어 보자
https://colab.research.google.com/drive/1p2uQFZ9csygq66fbRVAHoZKb1a8QLUr_?usp=sharing
### 3장 소스 코드 : 연산자로 계산을 해 보자
https://colab.research.google.com/drive/1Ve8yjkcuLtR281zT0BY5_unrmtsBy5Zd?usp=sharing
### 4장 소스 코드 : 조건을 따져 실행해보자
https://colab.research.google.com/drive/14sPhuL_Tp4Qr4VZlRStxn80gShwMhA5m?usp=sharing
### 5장 소스 코드 : 여러 번 반복하는 일을 하자
https://colab.research.google.com/drive/1tcxJZ5FdWOVQAPT0PgjqLmFR_GVXvmMB?usp=sharing
### 6장 소스 코드 : 함수로 일처리를 짜임새있게 하자
https://colab.research.google.com/drive/1y9LJeOqh3TCzXc_DSq3fefwcJNWveVF9?usp=sharing
### 7장 소스 코드 : 데이터를 리스트와 튜플로 묶어보자
https://colab.research.google.com/drive/1lVaO1eh1jDz0EwySoUrfS5Pcha5x4DqQ?usp=sharing
### 8장 소스 코드 : 연관된 데이터를 딕셔너리로 짝을 짓자
https://colab.research.google.com/drive/1YwTbUFdQYb6e9Hr4ofed3vYRg_VLSyzL?usp=sharing
### 9장 소스 코드 : 텍스트를 처리해보자
https://colab.research.google.com/drive/1v2M8X3WO6RyDyrMouevh_ejU8txTsCTZ?usp=sharing
### 10장 소스 코드 : 넘파이로 수치 데이터를 처리해보자
https://colab.research.google.com/drive/1P64IkDjmX0GsF-V1_fRxWnOvjUrQi68E?usp=sharing
### 11장 소스 코드 : 차트를 멋지게 그려보자
https://colab.research.google.com/drive/1tC1DbKqKyqsbco2eKCMOMi00VNngQ9bN?usp=sharing
### 12장 소스 코드 : 판다스로 데이터를 분석해보자
https://colab.research.google.com/drive/1Z4x-O7RaaLLFT-F-2fC_Or6xm8H3kcPI?usp=sharing
### 13장 소스 코드 : 시각 정보를 다루어보자
https://colab.research.google.com/drive/13wFyDe0faZG5JyOAZlyWeRHoRftVn6GJ?usp=sharing
### 14장 소스 코드 : 기계학습으로 똑똑한 컴퓨터를 만들자
https://colab.research.google.com/drive/193qDo9fsM0pK_xPzXStEqJFIQzfR-gKx?usp=sharing
### 15장 소스 코드 : 텐서플로우로 딥러닝의 맛을 보자
https://colab.research.google.com/drive/1HT2zrEQcO0mCy4sNEiB15DY5bVsJda00?usp=sharing
